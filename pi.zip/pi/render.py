"""
desky — Raspberry Pi widget renderers (Pillow / ImageDraw)
==========================================================

Drop-in replacements for render_clock(), render_weather(), render_music(),
render_tasks() and render_gif() in the Pi display script. Each returns a
240x320 RGB PIL.Image ready to push to the ILI9341 over SPI.

Design system: see the project's styles.css / tokens/*.css. Colors and the
two-size type scale below mirror those tokens exactly.

Only these ImageDraw primitives are used, per the hardware brief:
    rectangle()  text()  line()  ellipse()
No gradients, no blur, no shadows, no plugins.

Fonts: VT323 (hero numerals) and Press Start 2P (all labels/body). Download the
static TTFs once onto the Pi from Google Fonts:
    VT323-Regular.ttf          — hero numbers (time, temp, stat values)
    PressStart2P-Regular.ttf   — all labels, body text, captions
and point FONT_DIR at them. Falls back to PIL's default bitmap font if missing
(which actually looks okay for VT323 since it's a bitmap font — but P2P won't
substitute well for tiny label text).
"""

from PIL import Image, ImageDraw, ImageFont

# ----------------------------------------------------------------------------
# Canvas + palette  (mirrors tokens/colors.css)
# ----------------------------------------------------------------------------
W, H = 240, 320
PAD  = 22

BG        = (10, 10, 10)      # #0A0A0A
BG2       = (17, 17, 17)      # #111111
BG3       = (26, 26, 26)      # #1A1A1A
FG        = (242, 242, 242)   # #F2F2F2
FG_MUTED  = (107, 107, 107)   # #6B6B6B
FG_DIM    = (58, 58, 58)      # #3A3A3A
LINE      = (34, 34, 34)      # #222222

ACCENT_WARM  = (232, 201, 122)  # #E8C97A  clock / warm temps
ACCENT_COOL  = (122, 200, 232)  # #7AC8E8  cold temps
ACCENT_MUSIC = (252, 60, 68)    # #FC3C44  now playing
ACCENT_DONE  = (91, 209, 122)   # #5BD17A  completed tasks

FONT_DIR = "fonts"   # directory holding the SpaceGrotesk-*.ttf files


# ----------------------------------------------------------------------------
# Font + text helpers
# ----------------------------------------------------------------------------
def load_fonts(font_dir=FONT_DIR):
    """Load every size/weight the widgets need, once at startup."""
    def f(name, size):
        try:
            return ImageFont.truetype(f"{font_dir}/{name}.ttf", size)
        except OSError:
            return ImageFont.load_default()
    VT  = "VT323-Regular"           # hero numerals
    P2P = "PressStart2P-Regular"    # labels / body
    return {
        "time":     f(VT,  74),   # clock hero
        "temp":     f(VT,  66),   # weather temp number
        "h2":       f(VT,  24),   # stat values (humidity, feels)
        "hero":     f(P2P, 12),   # music track name
        "body":     f(P2P,  8),   # primary body text
        "body_r":   f(P2P,  7),   # secondary/dim body text
        "small":    f(P2P,  8),   # small labels
        "unit":     f(P2P, 10),   # temp unit °C
        "label":    f(P2P,  7),   # tiny caps labels
        "label_b":  f(P2P,  7),   # tiny caps labels bold (same font)
        "tiny":     f(P2P,  6),   # smallest text (stat keys)
    }


def tw(draw, text, font):
    """Width of a string in px."""
    return draw.textlength(text, font=font)


def tracked(draw, xy, text, font, fill, tracking=0, anchor="la"):
    """Draw `text` with extra letter-spacing (Pillow can't do tracking natively).

    anchor accepts the horizontal part 'l' or 'm' or 'r' for the WHOLE string;
    vertical is always top ('a' baseline of cap). Returns total width drawn."""
    chars = list(text)
    widths = [tw(draw, c, font) for c in chars]
    total = sum(widths) + tracking * max(len(chars) - 1, 0)
    x, y = xy
    if anchor[0] == "m":
        x -= total / 2
    elif anchor[0] == "r":
        x -= total
    for c, w in zip(chars, widths):
        draw.text((x, y), c, font=font, fill=fill)
        x += w + tracking
    return total


def seg_row(draw, cx, cy, segments, gap=0):
    """Draw a horizontally-centered row of differently-colored text segments.
    segments = [(text, font, fill), ...]. Vertically centered on cy (anchor 'mm')."""
    widths = [tw(draw, t, f) for t, f, _ in segments]
    total = sum(widths) + gap * (len(segments) - 1)
    x = cx - total / 2
    for (t, f, fill), w in zip(segments, widths):
        draw.text((x, cy), t, font=f, fill=fill, anchor="lm")
        x += w + gap


def new_canvas():
    img = Image.new("RGB", (W, H), BG)
    return img, ImageDraw.Draw(img)


# ----------------------------------------------------------------------------
# Widget 1 — clock
#   data = {"time": "14:32", "date": "06 JUN", "day": "SATURDAY", "secs": 47}
# ----------------------------------------------------------------------------
def render_clock(data, fonts):
    img, d = new_canvas()

    # top row: zone label (left) + seconds (right)
    tracked(d, (PAD, PAD), "BENGALURU", fonts["label"], FG_MUTED, tracking=2)
    secs = f"{int(data.get('secs', 0)):02d}"
    d.text((W - PAD, PAD), secs + "\u2033", font=fonts["small"], fill=ACCENT_WARM, anchor="ra")

    # hero time, centered — colon painted in the accent color
    hh, mm = data["time"].split(":")
    cy = 150
    seg_row(d, W // 2, cy, [
        (hh,  fonts["time"], FG),
        (":", fonts["time"], ACCENT_WARM),
        (mm,  fonts["time"], FG),
    ])

    # day · date row
    seg_row(d, W // 2, cy + 64, [
        (data["day"], fonts["small"], FG),
        ("  \u00b7  ",  fonts["small"], FG_DIM),
        (data["date"], fonts["small"], ACCENT_WARM),
    ])

    # seconds progress bar along the bottom
    by = H - PAD
    d.rectangle([PAD, by - 1, W - PAD, by + 1], fill=LINE)
    frac = int(data.get("secs", 0)) / 60.0
    d.rectangle([PAD, by - 1, PAD + (W - 2 * PAD) * frac, by + 1], fill=ACCENT_WARM)
    return img


# ----------------------------------------------------------------------------
# Widget 2 — weather
#   data = {"city","temp","cond","humidity","feels","icon"}
#   icon in: sun cloud partly rain storm snow fog
# ----------------------------------------------------------------------------
def temp_accent(temp_c):
    if temp_c >= 26: return ACCENT_WARM
    if temp_c <= 14: return ACCENT_COOL
    return FG


def _cloud(d, ox, oy, fill):
    """Filled cloud from 3 ellipses + a base rectangle. Anchored top-left of an
    ~58x36 box at (ox, oy)."""
    d.ellipse([ox+15, oy+5,  ox+15+26, oy+5+26],  fill=fill)   # big center puff
    d.ellipse([ox+2,  oy+14, ox+2+20,  oy+14+20], fill=fill)   # left puff
    d.ellipse([ox+30, oy+12, ox+30+22, oy+12+22], fill=fill)   # right puff
    d.rectangle([ox+8, oy+22, ox+52, oy+36], fill=fill)        # flat base


def _rays(d, cx, cy, r, color, only=None):
    import math
    dirs = [(0,-1),(0.7,-0.7),(1,0),(0.7,0.7),(0,1),(-0.7,0.7),(-1,0),(-0.7,-0.7)]
    for i,(dx,dy) in enumerate(dirs):
        if only and i not in only: continue
        d.line([cx+dx*(r+5), cy+dy*(r+5), cx+dx*(r+11), cy+dy*(r+11)],
               fill=color, width=3)


def draw_weather_icon(d, x, y, icon, accent):
    """Render into a 74x74 box with top-left at (x, y). Shapes only."""
    cx, cy = x + 37, y + 37
    if icon == "sun":
        d.ellipse([cx-15, cy-15, cx+15, cy+15], outline=accent, width=3)
        _rays(d, cx, cy, 15, accent)
    elif icon == "partly":
        sx, sy = x + 46, y + 26
        d.ellipse([sx-11, sy-11, sx+11, sy+11], outline=accent, width=3)
        _rays(d, sx, sy, 11, accent, only=[0,1,2,7])
        _cloud(d, x + 6, y + 30, FG)
    elif icon == "rain":
        _cloud(d, x, y + 6, FG)
        for dx in (26, 38, 50):
            d.line([x+dx, y+52, x+dx-4, y+62], fill=ACCENT_COOL, width=3)
    elif icon == "storm":
        _cloud(d, x, y + 6, FG)
        d.line([x+38, y+48, x+30, y+60], fill=ACCENT_WARM, width=3)
        d.line([x+30, y+60, x+40, y+58], fill=ACCENT_WARM, width=3)
        d.line([x+40, y+58, x+34, y+68], fill=ACCENT_WARM, width=3)
    elif icon == "snow":
        _cloud(d, x, y + 6, FG)
        for dx in (26, 38, 50):
            d.ellipse([x+dx-2, y+56, x+dx+2, y+60], fill=FG)
    elif icon == "fog":
        _cloud(d, x, y, FG)
        d.line([x+20, y+58, x+54, y+58], fill=FG_MUTED, width=3)
        d.line([x+24, y+66, x+50, y+66], fill=FG_MUTED, width=3)
    else:  # cloud
        _cloud(d, x + 8, y + 12, FG)


def render_weather(data, fonts):
    img, d = new_canvas()
    accent = temp_accent(int(str(data["temp"]).rstrip("\u00b0C ")) if str(data["temp"])[:2].isdigit() else 20)

    # city
    tracked(d, (PAD, PAD), data["city"].upper(), fonts["label"], FG_MUTED, tracking=2)

    # hero temperature (number + unit) on the left, icon on the right
    num = str(data["temp"]).replace("\u00b0C", "").replace("\u00b0", "").strip()
    ty = 120
    d.text((PAD, ty), num, font=fonts["temp"], fill=accent, anchor="lm")
    nx = PAD + tw(d, num, fonts["temp"])
    d.text((nx + 4, ty - 14), "\u00b0C", font=fonts["unit"], fill=FG_MUTED, anchor="lm")

    # condition under the temp
    d.text((PAD, ty + 44), data["cond"], font=fonts["body"], fill=FG, anchor="lm")

    # weather icon, right side
    draw_weather_icon(d, W - PAD - 74, ty - 50, data["icon"], accent)

    # bottom stats with a divider
    sy = H - 78
    d.line([PAD, sy, W - PAD, sy], fill=LINE, width=1)
    tracked(d, (PAD, sy + 14), "HUMIDITY", fonts["tiny"], FG_MUTED, tracking=1)
    d.text((PAD, sy + 30), data["humidity"], font=fonts["h2"], fill=FG)
    midx = W // 2 + 6
    tracked(d, (midx, sy + 14), "FEELS LIKE", fonts["tiny"], FG_MUTED, tracking=1)
    d.text((midx, sy + 30), data["feels"], font=fonts["h2"], fill=FG)
    return img


# ----------------------------------------------------------------------------
# Widget 3 — music (Apple Music / Last.fm now playing)
#   data = {"track","artist","album","elapsed","duration"}  (seconds ints)
# ----------------------------------------------------------------------------
def mmss(s):
    s = int(s)
    return f"{s//60}:{s%60:02d}"


def truncate(d, text, font, max_w):
    if tw(d, text, font) <= max_w:
        return text
    while text and tw(d, text + "\u2026", font) > max_w:
        text = text[:-1]
    return text + "\u2026"


def _music_note(d, x, y, color):
    """Small note: 2 heads (ellipses) + stems + beam (lines). ~26x30 box."""
    d.ellipse([x+1,  y+20, x+11, y+28], fill=color)
    d.ellipse([x+15, y+16, x+25, y+24], fill=color)
    d.line([x+10.5, y+24, x+10.5, y+6], fill=color, width=2)
    d.line([x+24.5, y+20, x+24.5, y+2], fill=color, width=2)
    d.line([x+10.5, y+6,  x+24.5, y+2], fill=color, width=2)


def render_music(data, fonts):
    img, d = new_canvas()

    # album-art block + note
    d.rectangle([PAD, PAD, PAD + 56, PAD + 56], fill=BG2)
    _music_note(d, PAD + 15, PAD + 13, FG_MUTED)

    # NOW PLAYING label + static equalizer bars
    lx = PAD + 56 + 14
    tracked(d, (lx, PAD + 4), "NOW PLAYING", fonts["label_b"], ACCENT_MUSIC, tracking=2)
    bar_y = PAD + 30
    for i, hgt in enumerate((6, 14, 9, 16)):       # frozen frame of the animation
        bx = lx + i * 6
        d.rectangle([bx, bar_y + (16 - hgt), bx + 3, bar_y + 16], fill=ACCENT_MUSIC)

    # track / artist / album (truncated)
    inner = W - 2 * PAD
    d.text((PAD, 150), truncate(d, data["track"], fonts["hero"], inner),
           font=fonts["hero"], fill=FG, anchor="lm")
    d.text((PAD, 182), truncate(d, data["artist"], fonts["body"], inner),
           font=fonts["body"], fill=FG, anchor="lm")
    d.text((PAD, 204), truncate(d, data["album"], fonts["body_r"], inner),
           font=fonts["body_r"], fill=FG_MUTED, anchor="lm")

    # progress bar + times
    by = H - 56
    d.rectangle([PAD, by - 1, W - PAD, by + 1], fill=LINE)
    frac = max(0.0, min(1.0, data["elapsed"] / max(1, data["duration"])))
    kx = PAD + (W - 2 * PAD) * frac
    d.rectangle([PAD, by - 1, kx, by + 1], fill=ACCENT_MUSIC)
    d.ellipse([kx - 3.5, by - 3.5, kx + 3.5, by + 3.5], fill=ACCENT_MUSIC)
    d.text((PAD, by + 16), mmss(data["elapsed"]), font=fonts["label"], fill=FG_MUTED, anchor="lm")
    d.text((W - PAD, by + 16), mmss(data["duration"]), font=fonts["label"], fill=FG_MUTED, anchor="rm")
    return img


# ----------------------------------------------------------------------------
# Widget 4 — tasks
#   data = {"items": [{"t": "...", "done": bool}, ...]}
# ----------------------------------------------------------------------------
def render_tasks(data, fonts):
    img, d = new_canvas()
    items = data["items"]
    done  = sum(1 for it in items if it["done"])
    n     = len(items)

    # header
    tracked(d, (PAD, PAD), "TASKS", fonts["label_b"], FG_MUTED, tracking=2)
    d.text((W - PAD, PAD), f"{done}/{n}", font=fonts["small"], fill=ACCENT_DONE, anchor="ra")
    hy = PAD + 22
    d.line([PAD, hy, W - PAD, hy], fill=LINE, width=1)

    # list
    row_h = 34
    top = hy + 18
    for i, it in enumerate(items):
        cy = top + i * row_h + row_h // 2
        bx = PAD
        if it["done"]:
            d.rectangle([bx, cy - 8, bx + 16, cy + 8], fill=ACCENT_DONE)
            # checkmark (two lines) in the bg color
            d.line([bx + 4, cy, bx + 7, cy + 3], fill=BG, width=2)
            d.line([bx + 7, cy + 3, bx + 12, cy - 4], fill=BG, width=2)
            color, font = FG_DIM, fonts["body_r"]
        else:
            d.rectangle([bx, cy - 8, bx + 16, cy + 8], outline=FG_DIM, width=2)
            color, font = FG, fonts["body"]
        tx = bx + 28
        d.text((tx, cy), it["t"], font=font, fill=color, anchor="lm")
        if it["done"]:                                  # strikethrough line
            d.line([tx, cy, tx + tw(d, it["t"], font), cy], fill=FG_DIM, width=1)

    # footer: caption + progress bar
    fy = H - PAD - 12
    tracked(d, (PAD, fy - 8), f"{done} OF {n} DONE", fonts["tiny"], FG_MUTED, tracking=1)
    d.rectangle([PAD, fy + 10, W - PAD, fy + 12], fill=LINE)
    d.rectangle([PAD, fy + 10, PAD + (W - 2 * PAD) * (done / n), fy + 12], fill=ACCENT_DONE)
    return img


# ----------------------------------------------------------------------------
# Widget 5 — gif (pixel-art frame / container)
#   Draws the generated 15x20 pixel sunset; overlay a real GIF frame instead by
#   pasting it over the canvas. Kept here as the static placeholder.
# ----------------------------------------------------------------------------
import math

_RIDGE = [14,12,11,9,10,12,10,8,9,11,12,11,10,12,14]
_STARS = {(2,1),(12,2),(5,3),(10,4),(1,5),(13,5)}
_SUN_CX, _SUN_CY, _SUN_R, _HORIZON = 7, 7, 2.7, 15
_SUN  = ACCENT_WARM
_MOUNT, _LAND, _GLOW = (21,22,31), (12,12,12), (58,36,24)

def _sky(r):
    if r <= 1:  return (11,18,38)
    if r <= 3:  return (22,33,63)
    if r <= 5:  return (42,35,80)
    if r <= 7:  return (90,47,92)
    if r <= 9:  return (154,66,87)
    if r <= 11: return (207,106,57)
    return (230,154,74)

def _cell(r, c):
    col = _sky(r)
    if r <= _HORIZON and math.hypot(c - _SUN_CX, r - _SUN_CY) <= _SUN_R:
        col = _SUN
    if _RIDGE[c] <= r <= _HORIZON:
        col = _MOUNT
    if r > _HORIZON:
        col = _LAND
    if r == 16 and abs(c - _SUN_CX) <= 2: col = _GLOW
    if r == 17 and abs(c - _SUN_CX) <= 1: col = _GLOW
    if (c, r) in _STARS and col == _sky(r): col = FG
    return col

def render_gif(data, fonts):
    img, d = new_canvas()
    cols, rows = 15, 20
    cw, ch = W / cols, H / rows
    for r in range(rows):
        for c in range(cols):
            d.rectangle([round(c*cw), round(r*ch), round((c+1)*cw), round((r+1)*ch)],
                        fill=_cell(r, c))
    # GIF chip (top-left)
    d.rectangle([10, 10, 64, 32], fill=BG)
    d.rectangle([18, 17, 25, 24], fill=ACCENT_MUSIC)
    tracked(d, (31, 14), "GIF", fonts["label_b"], FG, tracking=3)
    # thin frame
    d.rectangle([0, 0, W - 1, H - 1], outline=(28, 28, 28), width=1)
    return img


# ----------------------------------------------------------------------------
# Local test harness — renders one PNG per widget
# ----------------------------------------------------------------------------
if __name__ == "__main__":
    F = load_fonts()
    render_clock({"time":"14:32","date":"06 JUN","day":"SATURDAY","secs":47}, F).save("out_clock.png")
    render_weather({"city":"BANGALORE","temp":"28","cond":"Partly Cloudy",
                    "humidity":"72%","feels":"30\u00b0","icon":"partly"}, F).save("out_weather.png")
    render_music({"track":"Midnight City","artist":"M83",
                  "album":"Hurry Up, We're Dreaming","elapsed":83,"duration":244}, F).save("out_music.png")
    render_tasks({"items":[
        {"t":"Solder SPI displays","done":True},
        {"t":"Deploy Go backend","done":True},
        {"t":"Wire Last.fm scrobbles","done":False},
        {"t":"Design GIF widget","done":False},
        {"t":"3D-print enclosure","done":False},
    ]}, F).save("out_tasks.png")
    render_gif({}, F).save("out_gif.png")
    print("rendered out_*.png")
